package com.anis.unss;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import com.getcapacitor.JSArray;
import com.getcapacitor.JSObject;
import com.getcapacitor.Plugin;
import com.getcapacitor.PluginCall;
import com.getcapacitor.PluginMethod;
import com.getcapacitor.annotation.CapacitorPlugin;
import org.json.JSONObject;
import org.json.JSONArray;

@CapacitorPlugin(name = "AdhanOverlay")
public class AdhanOverlayPlugin extends Plugin {
    @PluginMethod
    public void scheduleAlarms(PluginCall call) {
        JSArray alarms = call.getArray("alarms", new JSArray());
        Context context = getContext();
        AlarmManager manager = (AlarmManager) context.getSystemService(Context.ALARM_SERVICE);
        // Persist the schedule so alarms can be restored after Android restarts.
        try { context.getSharedPreferences("anis_adhan", Context.MODE_PRIVATE).edit().putString("alarms", alarms.toString()).apply(); } catch (Exception ignored) {}
        // Clear the seven-day set first, so changed prayer times do not leave stale alarms.
        for (int day = 0; day < 7; day++) {
            for (int prayer = 0; prayer < 6; prayer++) {
                int id = 810000 + day * 10 + prayer;
                PendingIntent old = alarmIntent(context, id, "", false);
                if (old != null) manager.cancel(old);
            }
        }
        try {
            for (int i = 0; i < alarms.length(); i++) {
                JSONObject item = alarms.getJSONObject(i);
                int id = item.getInt("id");
                long at = item.getLong("at");
                String prayer = item.optString("prayer", "الصلاة");
                if (at <= System.currentTimeMillis()) continue;
                PendingIntent pi = alarmIntent(context, id, prayer, true);
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    try { manager.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi); }
                    catch (SecurityException denied) { manager.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi); }
                } else manager.setExact(AlarmManager.RTC_WAKEUP, at, pi);
            }
            JSObject result = new JSObject(); result.put("scheduled", alarms.length()); call.resolve(result);
        } catch (Exception e) { call.reject("تعذرت جدولة واجهة الأذان", e); }
    }

    private PendingIntent alarmIntent(Context context, int id, String prayer, boolean create) {
        Intent intent = new Intent(context, AdhanAlarmReceiver.class);
        intent.putExtra("prayer", prayer);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= 23) flags |= PendingIntent.FLAG_IMMUTABLE;
        return PendingIntent.getBroadcast(context, id, intent, create ? flags : (flags | PendingIntent.FLAG_NO_CREATE));
    }
}
